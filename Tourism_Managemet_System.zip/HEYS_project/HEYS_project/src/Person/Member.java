package Person;

import Tour.Tour;

import java.util.ArrayList;

public class Member extends Person {

    protected ArrayList<Tour> membertours = new ArrayList<>();
    protected String telephone;
    protected String eMail;
    protected int howMany;
    protected String discountCoupon;

    protected String cardNumber;

    public Member() {
    }

    public Member(String name, String surname, String mail, String telephone, String username, String password) {
        super(username, password, name, surname);
        this.eMail = mail;
        this.telephone = telephone;
    }

    public String getTelephone() {
        return telephone;
    }

    public String geteMail() {
        return eMail;
    }

    public String getUserName() {
        return userName;
    }

    @Override
    public String toString() {
        return "Name:" + this.name
                + "\nSurname" + this.surname;
    }

}
