package Person;

public abstract class Person {

    protected String userName;
    protected String password;
    protected String name;
    protected String surname;

    public Person() {
    }

    public Person(String userName, String password, String name, String surname) {
        this.userName = userName;
        this.password = password;
        this.name = name;
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public boolean check(String username, String password) {
        if (this.userName.equals(username) & this.password.equals(password)) {
            return true;
        } else {
            return false;
        }
    }

}
