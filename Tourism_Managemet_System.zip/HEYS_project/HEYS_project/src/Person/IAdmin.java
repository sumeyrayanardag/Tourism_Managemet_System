package Person;

import Tour.Tour;

public interface IAdmin {

    public boolean removeTour(int tourindex);

    public boolean deleteMember(int memberindex);

    public boolean addTour(Tour tours);

    public String getAllMember();

    public String showMoney();

    public int searchMember(String username);

    public int searchTour(String newtourname);

}
