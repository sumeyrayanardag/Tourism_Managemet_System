package Person;

import Tour.Tour;
import java.util.ArrayList;

public class Admin extends Person implements IAdmin {

    protected ArrayList<Tour> admintours = new ArrayList<>();
    protected ArrayList<Member> members = new ArrayList<>();
    protected ArrayList<String> coupons = new ArrayList<>();

    public Admin(String userName, String password, String name, String surname) {
        super(userName, password, name, surname);
    }

    public ArrayList<Tour> getAdmintours() {
        return admintours;
    }

    public String addingforNewTour(String starts) {
        String res = "";
        for (int i = 0; i < admintours.size(); i++) {
            if (admintours.get(i).getTourName().startsWith(starts)) {
                res += admintours.get(i).toString();
            }
        }
        return res;
    }

    public ArrayList<Tour> contentWith(String content) {
        ArrayList<Tour> find = new ArrayList<>();
        for (int i = 0; i < getAdmintours().size(); i++) {
            if (getAdmintours().get(i).getTourName().toLowerCase().contains(content.toLowerCase())) {
                find.add(getAdmintours().get(i));
            }
        }
        return find;
    }

    @Override
    public boolean deleteMember(int memberindex) {
        if (memberindex == -1) {
            return false;
        }
        return members.remove(members.get(memberindex));
    }

    @Override
    public boolean addTour(Tour newtours) {
        return admintours.add(newtours);
    }

    @Override
    public String getAllMember() {
        String res = "";
        for (int i = 0; i < members.size(); i++) {
            res += members.get(i).toString() + "\n";
        }
        return res;
    }

    @Override
    public String showMoney() {
        return null;
    }

    @Override
    public int searchTour(String newtourname) {

        for (int i = 0; i < admintours.size(); i++) {
            if (admintours.get(i).getTourName().equalsIgnoreCase(newtourname)) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public boolean removeTour(int tourindex) {
        if (tourindex == -1) {
            return false;
        }
        return admintours.remove(admintours.get(tourindex));

    }

    @Override
    public int searchMember(String username) {
        for (int i = 0; i < members.size(); i++) {
            if (members.get(i).getUserName().equalsIgnoreCase(username)) {
                return i;
            }
        }
        return -1;
    }

}
