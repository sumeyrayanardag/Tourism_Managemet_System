package Tour;

public class SummerTour extends Tour {

    protected String hotelName;
    protected String beachName;
    protected String region;
    protected String place_to_visit;

    public SummerTour() {

    }

    public SummerTour(String hotelName, String beachName, String region, String place_to_visit, String tourName, String howManyDay, int capacity, double price, int first_day, int first_month, int first_year, int last_day, int last_month, int last_year, String imageURL) {
        super(tourName, howManyDay, capacity, price, first_day, first_month, first_year, last_day, last_month, last_year, imageURL);
        this.hotelName = hotelName;
        this.beachName = beachName;
        this.region = region;
        this.place_to_visit = place_to_visit;
    }

    public String getHotelName() {
        return hotelName;
    }

    public String getBeachName() {
        return beachName;
    }

    public String getRegion() {
        return region;
    }

    public String getPlace_to_visit() {
        return place_to_visit;
    }

    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }

    public void setBeachName(String beachName) {
        this.beachName = beachName;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public void setPlace_to_visit(String place_to_visit) {
        this.place_to_visit = place_to_visit;
    }

    @Override
    public String informationMessage() {
        return "There is only service in summer\nThese tours start from Ankara,Izmir,Istanbul and Erzurum";
    }

    @Override
    public String toString() {
        return "Summer Tour\n" + super.toString() + "\nHotel Name: " + hotelName
                + "\nBeach Name: " + beachName
                + "\nRegion: " + region
                + "\nplace_to_visit: " + place_to_visit;
    }

}
