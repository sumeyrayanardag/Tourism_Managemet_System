
package Tour;

public class CampingTour extends Tour {

    protected String placeToCampingArea;

    public CampingTour() {
    }
    
    public CampingTour(String placeToCampingArea, String tourName, String howManyDay, int capacity, double price, int first_day, int first_month, int first_year, int last_day, int last_month, int last_year, String imageURL) {
        super(tourName, howManyDay, capacity, price, first_day, first_month, first_year, last_day, last_month, last_year, imageURL);
        this.placeToCampingArea = placeToCampingArea;
    }

    public String getPlaceToCampingArea() {
        return placeToCampingArea;
    }
    
    public void setPlaceToCampingArea(String placeToCampingArea) {
        this.placeToCampingArea = placeToCampingArea;
    }

    @Override
    public String toString() {
        return "Camping Tour\n" + super.toString() + "\nCamping Area: " + placeToCampingArea;
    }
    
     @Override
    public String informationMessage() {
        return "There is no service in the winter, if you dont have any tent, you will pay extra for it\nAll tours start point is city center.";
    }

}
