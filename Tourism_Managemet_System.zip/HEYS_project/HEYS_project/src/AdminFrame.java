
import Person.Admin;
import Tour.*;
import java.awt.Font;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AdminFrame extends javax.swing.JFrame {

    Admin admin1 = new Admin("a", "a", "hum", "tezcan");
    int size;                           //to check tour added or not
    int searched_tour_index_delete;     //in delete panel, tour name will search then if that tour name is founded, its index equals searched_tour_index_delete
    int searched_tour_index_edit;       //in delete edit, tour name will search then if that tour name is founded, its index equals searched_tour_index_edit
    ArrayList<Basket> basketlist = new ArrayList<>();

    public AdminFrame() {
        initComponents();

        //get current date and set unselectable date before the current date on calendars'
        LocalDate localDate = LocalDate.now();
        java.util.Date date = java.sql.Date.valueOf(localDate);
        dateChooser_first_add.setMinSelectableDate(date);
        dateChooser_last_add.setMinSelectableDate(date);
        dateChooser_finish_edit.setMinSelectableDate(date);
        dateChooser_start_edit.setMinSelectableDate(date);

        //in delete section, first search then if item founded, delete button and ta can visible
        bt_delete.setVisible(false);
        ta_message_delete.setVisible(false);

        //panel of tour types will visible when tour type was selected on add and/or edit panels
        panel_card_add.setVisible(false);
        panel_camping_add.setVisible(false);
        panel_cultural_add.setVisible(false);
        panel_mixed_add.setVisible(false);
        panel_natural_add.setVisible(false);
        panel_summer_add.setVisible(false);
        panel_winter_add.setVisible(false);

        panel_card_edit.setVisible(false);
        panel_camping_edit.setVisible(false);
        panel_cultural_edit.setVisible(false);
        panel_mixed_edit.setVisible(false);
        panel_natural_edit.setVisible(false);
        panel_summer_edit.setVisible(false);
        panel_winter_edit.setVisible(false);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        tabbed_pane_admin = new javax.swing.JTabbedPane();
        panel_add = new javax.swing.JPanel();
        tf_tourName_add = new javax.swing.JTextField();
        tf_capacity_add = new javax.swing.JTextField();
        tf_price_add = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        bt_add = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        ta_message_add = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        tf_howManyDay = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        tf_imageURL_add = new javax.swing.JTextField();
        panel_card_add = new javax.swing.JPanel();
        panel_mixed_add = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        tf_cityName_mixed_add = new javax.swing.JTextField();
        tf_placeToVisit_mixed_add = new javax.swing.JTextField();
        panel_natural_add = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        tf_bungalowName_natural_add = new javax.swing.JTextField();
        jLabel49 = new javax.swing.JLabel();
        tf_region_natural_add = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        tf_placeToVisit_natural_add = new javax.swing.JTextField();
        panel_summer_add = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        tf_hıtelNAme_summer_add = new javax.swing.JTextField();
        tf_beachName_summer_add = new javax.swing.JTextField();
        tf_region_summer_add = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        tf_placeToVisit_summer_add = new javax.swing.JTextField();
        panel_winter_add = new javax.swing.JPanel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        tf_skiResortName_winter_add = new javax.swing.JTextField();
        tf_hotelName_winter_add = new javax.swing.JTextField();
        panel_camping_add = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        tf_placeToCampAr_camping_add = new javax.swing.JTextField();
        panel_cultural_add = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        tf_cityName_cultural_add = new javax.swing.JTextField();
        tf_hotelName_cultural_add = new javax.swing.JTextField();
        tf_placeToVisit_cultural_add = new javax.swing.JTextField();
        comboBox_add = new javax.swing.JComboBox<>();
        jLabel37 = new javax.swing.JLabel();
        dateChooser_first_add = new com.toedter.calendar.JDateChooser();
        dateChooser_last_add = new com.toedter.calendar.JDateChooser();
        jLabel51 = new javax.swing.JLabel();
        panel_display = new javax.swing.JPanel();
        bt_display = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        scrollPane_add1 = new javax.swing.JScrollPane();
        CulturalTable = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        scrollPane_add2 = new javax.swing.JScrollPane();
        NaturalTable = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        scrollPane_add3 = new javax.swing.JScrollPane();
        SummerTable = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        scrollPane_add4 = new javax.swing.JScrollPane();
        WinterTable = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        scrollPane_add5 = new javax.swing.JScrollPane();
        MixedTable = new javax.swing.JTable();
        jPanel7 = new javax.swing.JPanel();
        scrollPane_add = new javax.swing.JScrollPane();
        CampingTable = new javax.swing.JTable();
        jLabel54 = new javax.swing.JLabel();
        panel_edit = new javax.swing.JPanel();
        tf_tourName_edit = new javax.swing.JTextField();
        tf_capacity_edit = new javax.swing.JTextField();
        tf_price_edit = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        bt_edit = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        tf_tourName_search_edit = new javax.swing.JTextField();
        bt_search_edit = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        ta_message_edit = new javax.swing.JTextArea();
        jScrollPane6 = new javax.swing.JScrollPane();
        ta_search_result_edit = new javax.swing.JTextArea();
        jLabel19 = new javax.swing.JLabel();
        tf_howManyDay_edit = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        tf_tourFinishDate_edit = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        tf_tourStartDate_edit = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        tf_imageURL_edit = new javax.swing.JTextField();
        panel_card_edit = new javax.swing.JPanel();
        panel_camping_edit = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        tf_placeToCampAr_camping_edit = new javax.swing.JTextField();
        panel_cultural_edit = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        tf_cityName_cultural_edit = new javax.swing.JTextField();
        tf_hotelName_cultural_edit = new javax.swing.JTextField();
        tf_placeToVisit_cultural_edit = new javax.swing.JTextField();
        panel_mixed_edit = new javax.swing.JPanel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        tf_cityName_mixed_edit = new javax.swing.JTextField();
        tf_placeToVisit_mixed_edit = new javax.swing.JTextField();
        panel_natural_edit = new javax.swing.JPanel();
        jLabel42 = new javax.swing.JLabel();
        tf_bungalowName_natural_edit = new javax.swing.JTextField();
        jLabel50 = new javax.swing.JLabel();
        tf_region_natural_edit = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        tf_placeToVisit_natural_edit = new javax.swing.JTextField();
        panel_summer_edit = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        tf_hotelName_summer_edit = new javax.swing.JTextField();
        tf_beachName_summer_edit = new javax.swing.JTextField();
        tf_region_summer_edit = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        tf_placeToVisit_summer_edit = new javax.swing.JTextField();
        panel_winter_edit = new javax.swing.JPanel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        tf_skiResortName_winter_edit = new javax.swing.JTextField();
        tf_hotelName_winter_edit = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        tf_tourType_edit = new javax.swing.JTextField();
        dateChooser_start_edit = new com.toedter.calendar.JDateChooser();
        dateChooser_finish_edit = new com.toedter.calendar.JDateChooser();
        jLabel55 = new javax.swing.JLabel();
        panel_delete = new javax.swing.JPanel();
        tf_tourName_delete = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        bt_delete = new javax.swing.JButton();
        bt_search_delete = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        ta_search_result_delete = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        ta_message_delete = new javax.swing.JTextArea();
        jLabel52 = new javax.swing.JLabel();
        panel_money = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        ta_display_money = new javax.swing.JTextArea();
        bt_show_money = new javax.swing.JButton();
        jLabel53 = new javax.swing.JLabel();

        jButton1.setText("jButton1");

        tabbed_pane_admin.setBackground(new java.awt.Color(204, 204, 255));
        tabbed_pane_admin.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        tabbed_pane_admin.setOpaque(true);
        tabbed_pane_admin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tabbed_pane_adminKeyPressed(evt);
            }
        });

        panel_add.setFont(new java.awt.Font("Tw Cen MT", 0, 11)); // NOI18N
        panel_add.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tf_tourName_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        panel_add.add(tf_tourName_add, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 10, 119, -1));

        tf_capacity_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        panel_add.add(tf_capacity_add, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 70, 119, -1));

        tf_price_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        panel_add.add(tf_price_add, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 110, 119, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel7.setText("Tour Name: ");
        panel_add.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(46, 14, -1, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel11.setText("Capacity: ");
        panel_add.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(46, 76, -1, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel12.setText("Price: ");
        panel_add.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, -1, -1));

        bt_add.setFont(new java.awt.Font("Mongolian Baiti", 1, 15)); // NOI18N
        bt_add.setText("ADD");
        bt_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_addActionPerformed(evt);
            }
        });
        panel_add.add(bt_add, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 409, 94, -1));

        ta_message_add.setColumns(20);
        ta_message_add.setFont(new java.awt.Font("Monospaced", 1, 14)); // NOI18N
        ta_message_add.setRows(5);
        ta_message_add.setBorder(null);
        jScrollPane1.setViewportView(ta_message_add);

        panel_add.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 454, 244, 108));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel5.setText("First Date: ");
        panel_add.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 140, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel6.setText("How Many Day:");
        panel_add.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(46, 45, -1, -1));

        tf_howManyDay.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        panel_add.add(tf_howManyDay, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 40, 119, -1));

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel24.setText("Last Date: ");
        panel_add.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, -1, -1));

        jLabel27.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel27.setText("Image URL: ");
        panel_add.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, -1, -1));

        tf_imageURL_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        panel_add.add(tf_imageURL_add, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 200, 119, -1));

        panel_card_add.setLayout(new java.awt.CardLayout());

        panel_mixed_add.setBackground(new java.awt.Color(204, 204, 255));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel10.setText("City Name:");

        jLabel29.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel29.setText("Place To Visit: ");

        tf_cityName_mixed_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        tf_placeToVisit_mixed_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        javax.swing.GroupLayout panel_mixed_addLayout = new javax.swing.GroupLayout(panel_mixed_add);
        panel_mixed_add.setLayout(panel_mixed_addLayout);
        panel_mixed_addLayout.setHorizontalGroup(
            panel_mixed_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_mixed_addLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_mixed_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_mixed_addLayout.createSequentialGroup()
                        .addComponent(jLabel29)
                        .addGap(43, 43, 43))
                    .addGroup(panel_mixed_addLayout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(66, 66, 66)))
                .addGroup(panel_mixed_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(tf_cityName_mixed_add)
                    .addComponent(tf_placeToVisit_mixed_add, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE))
                .addGap(0, 198, Short.MAX_VALUE))
        );
        panel_mixed_addLayout.setVerticalGroup(
            panel_mixed_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_mixed_addLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(panel_mixed_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(tf_cityName_mixed_add, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_mixed_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(tf_placeToVisit_mixed_add, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(183, Short.MAX_VALUE))
        );

        panel_card_add.add(panel_mixed_add, "card5");

        panel_natural_add.setBackground(new java.awt.Color(204, 204, 255));

        jLabel30.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel30.setText("Bungalow Name: ");

        tf_bungalowName_natural_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        tf_bungalowName_natural_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_bungalowName_natural_addActionPerformed(evt);
            }
        });

        jLabel49.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel49.setText("Region:");

        tf_region_natural_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        tf_region_natural_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_region_natural_addActionPerformed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel20.setText("Place To Visit: ");

        tf_placeToVisit_natural_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        javax.swing.GroupLayout panel_natural_addLayout = new javax.swing.GroupLayout(panel_natural_add);
        panel_natural_add.setLayout(panel_natural_addLayout);
        panel_natural_addLayout.setHorizontalGroup(
            panel_natural_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_natural_addLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(panel_natural_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel30)
                    .addComponent(jLabel49)
                    .addComponent(jLabel20))
                .addGap(43, 43, 43)
                .addGroup(panel_natural_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tf_placeToVisit_natural_add, javax.swing.GroupLayout.DEFAULT_SIZE, 173, Short.MAX_VALUE)
                    .addComponent(tf_region_natural_add)
                    .addComponent(tf_bungalowName_natural_add))
                .addContainerGap(143, Short.MAX_VALUE))
        );
        panel_natural_addLayout.setVerticalGroup(
            panel_natural_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_natural_addLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(panel_natural_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel30)
                    .addComponent(tf_bungalowName_natural_add, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(panel_natural_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel49)
                    .addComponent(tf_region_natural_add, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_natural_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(tf_placeToVisit_natural_add, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(146, Short.MAX_VALUE))
        );

        panel_card_add.add(panel_natural_add, "card4");

        panel_summer_add.setBackground(new java.awt.Color(204, 204, 255));

        jLabel32.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel32.setText("Hotel Name: ");

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel33.setText("Beach Name: ");

        jLabel34.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel34.setText("Region: ");

        tf_hıtelNAme_summer_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        tf_beachName_summer_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        tf_region_summer_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        jLabel31.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel31.setText("Place to Visit: ");

        tf_placeToVisit_summer_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        javax.swing.GroupLayout panel_summer_addLayout = new javax.swing.GroupLayout(panel_summer_add);
        panel_summer_add.setLayout(panel_summer_addLayout);
        panel_summer_addLayout.setHorizontalGroup(
            panel_summer_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_summer_addLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_summer_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel32)
                    .addComponent(jLabel33)
                    .addComponent(jLabel34)
                    .addComponent(jLabel31))
                .addGap(37, 37, 37)
                .addGroup(panel_summer_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(tf_beachName_summer_add, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 163, Short.MAX_VALUE)
                    .addComponent(tf_hıtelNAme_summer_add, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tf_region_summer_add, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tf_placeToVisit_summer_add))
                .addGap(0, 199, Short.MAX_VALUE))
        );
        panel_summer_addLayout.setVerticalGroup(
            panel_summer_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_summer_addLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(panel_summer_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(tf_hıtelNAme_summer_add, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(panel_summer_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel33)
                    .addComponent(tf_beachName_summer_add, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_summer_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34)
                    .addComponent(tf_region_summer_add, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(panel_summer_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel31)
                    .addComponent(tf_placeToVisit_summer_add, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(82, Short.MAX_VALUE))
        );

        panel_card_add.add(panel_summer_add, "card3");

        panel_winter_add.setBackground(new java.awt.Color(204, 204, 255));

        jLabel35.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel35.setText("Ski Resort Name: ");

        jLabel36.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel36.setText("Hotel name: ");

        tf_skiResortName_winter_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        tf_hotelName_winter_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        javax.swing.GroupLayout panel_winter_addLayout = new javax.swing.GroupLayout(panel_winter_add);
        panel_winter_add.setLayout(panel_winter_addLayout);
        panel_winter_addLayout.setHorizontalGroup(
            panel_winter_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_winter_addLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(panel_winter_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel36)
                    .addComponent(jLabel35))
                .addGap(40, 40, 40)
                .addGroup(panel_winter_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tf_hotelName_winter_add, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tf_skiResortName_winter_add, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(157, Short.MAX_VALUE))
        );

        panel_winter_addLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {tf_hotelName_winter_add, tf_skiResortName_winter_add});

        panel_winter_addLayout.setVerticalGroup(
            panel_winter_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_winter_addLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(panel_winter_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel35)
                    .addComponent(tf_skiResortName_winter_add, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_winter_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel36)
                    .addComponent(tf_hotelName_winter_add, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(231, Short.MAX_VALUE))
        );

        panel_card_add.add(panel_winter_add, "card2");

        panel_camping_add.setBackground(new java.awt.Color(204, 204, 255));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel3.setText("Place To Camping Area: ");

        tf_placeToCampAr_camping_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        javax.swing.GroupLayout panel_camping_addLayout = new javax.swing.GroupLayout(panel_camping_add);
        panel_camping_add.setLayout(panel_camping_addLayout);
        panel_camping_addLayout.setHorizontalGroup(
            panel_camping_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_camping_addLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(26, 26, 26)
                .addComponent(tf_placeToCampAr_camping_add, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(140, Short.MAX_VALUE))
        );
        panel_camping_addLayout.setVerticalGroup(
            panel_camping_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_camping_addLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_camping_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(tf_placeToCampAr_camping_add, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(293, Short.MAX_VALUE))
        );

        panel_card_add.add(panel_camping_add, "card7");

        panel_cultural_add.setBackground(new java.awt.Color(204, 204, 255));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel4.setText("City Name:");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel8.setText("Hotel Name: ");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel9.setText("Place To Visit: ");

        tf_cityName_cultural_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        tf_hotelName_cultural_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        tf_placeToVisit_cultural_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        javax.swing.GroupLayout panel_cultural_addLayout = new javax.swing.GroupLayout(panel_cultural_add);
        panel_cultural_add.setLayout(panel_cultural_addLayout);
        panel_cultural_addLayout.setHorizontalGroup(
            panel_cultural_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_cultural_addLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_cultural_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(jLabel4)
                    .addComponent(jLabel9))
                .addGap(31, 31, 31)
                .addGroup(panel_cultural_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_cultural_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(tf_hotelName_cultural_add, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tf_cityName_cultural_add, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(tf_placeToVisit_cultural_add, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(187, Short.MAX_VALUE))
        );

        panel_cultural_addLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {tf_cityName_cultural_add, tf_hotelName_cultural_add, tf_placeToVisit_cultural_add});

        panel_cultural_addLayout.setVerticalGroup(
            panel_cultural_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_cultural_addLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(panel_cultural_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tf_cityName_cultural_add, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_cultural_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(tf_hotelName_cultural_add, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panel_cultural_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(tf_placeToVisit_cultural_add, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(173, Short.MAX_VALUE))
        );

        panel_card_add.add(panel_cultural_add, "card6");

        panel_add.add(panel_card_add, new org.netbeans.lib.awtextra.AbsoluteConstraints(518, 11, -1, -1));

        comboBox_add.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        comboBox_add.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Camping", "Natural", "Cultural", "Winter", "Summer", "Mixed" }));
        comboBox_add.setSelectedIndex(-1);
        comboBox_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBox_addActionPerformed(evt);
            }
        });
        panel_add.add(comboBox_add, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 182, -1));

        jLabel37.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel37.setText("Select Tour Type:");
        panel_add.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 155, -1));
        panel_add.add(dateChooser_first_add, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 140, 120, -1));
        panel_add.add(dateChooser_last_add, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 170, 120, -1));

        jLabel51.setBackground(new java.awt.Color(204, 204, 255));
        jLabel51.setOpaque(true);
        panel_add.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1080, 900));

        tabbed_pane_admin.addTab("ADD", panel_add);

        panel_display.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        bt_display.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        bt_display.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons8_refresh_50px.png"))); // NOI18N
        bt_display.setText("Display and Refresh");
        bt_display.setBorderPainted(false);
        bt_display.setContentAreaFilled(false);
        bt_display.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bt_display.setFocusPainted(false);
        bt_display.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_displayActionPerformed(evt);
            }
        });
        panel_display.add(bt_display, new org.netbeans.lib.awtextra.AbsoluteConstraints(35, 11, 270, 50));

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));

        CulturalTable.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        CulturalTable.setFont(new java.awt.Font("Tw Cen MT", 0, 15)); // NOI18N
        CulturalTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tour Name", "How Many Day", "Capacity", "Price", "Date", "Image URL", "Hotel Name", "City Name", "Place to Visit"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Double.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        scrollPane_add1.setViewportView(CulturalTable);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(32, Short.MAX_VALUE)
                .addComponent(scrollPane_add1, javax.swing.GroupLayout.PREFERRED_SIZE, 860, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(scrollPane_add1, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(417, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Cultural", jPanel1);

        jPanel3.setBackground(new java.awt.Color(204, 204, 255));

        NaturalTable.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        NaturalTable.setFont(new java.awt.Font("Tw Cen MT", 0, 14)); // NOI18N
        NaturalTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tour Name", "How Many Day", "Capacity", "Price", "Date", "Image URL", "Bungalow Name", "Region", "Place to Visit"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Double.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        scrollPane_add2.setViewportView(NaturalTable);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(scrollPane_add2, javax.swing.GroupLayout.PREFERRED_SIZE, 860, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(36, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(scrollPane_add2, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(408, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Natural", jPanel3);

        jPanel4.setBackground(new java.awt.Color(204, 204, 255));

        SummerTable.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        SummerTable.setFont(new java.awt.Font("Tw Cen MT", 0, 14)); // NOI18N
        SummerTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tour Name", "How Many Day", "Capacity", "Price", "Date", "Image URL", "Hotel Name", "Beach Name", "Region", "Place to Visit"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Double.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        scrollPane_add3.setViewportView(SummerTable);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(scrollPane_add3, javax.swing.GroupLayout.PREFERRED_SIZE, 860, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(scrollPane_add3, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(418, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Summer", jPanel4);

        jPanel5.setBackground(new java.awt.Color(204, 204, 255));

        WinterTable.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        WinterTable.setFont(new java.awt.Font("Tw Cen MT", 0, 14)); // NOI18N
        WinterTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tour Name", "How Many Day", "Capacity", "Price", "Date", "Image URL", "Ski Resort Namel", "Hotel Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Double.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        scrollPane_add4.setViewportView(WinterTable);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(scrollPane_add4, javax.swing.GroupLayout.DEFAULT_SIZE, 894, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(scrollPane_add4, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(427, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Winter", jPanel5);

        jPanel6.setBackground(new java.awt.Color(204, 204, 255));

        MixedTable.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        MixedTable.setFont(new java.awt.Font("Tw Cen MT", 0, 14)); // NOI18N
        MixedTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tour Name", "How Many Day", "Capacity", "Price", "Date", "Image URL", "City Name", "Place to Visit"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Double.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        scrollPane_add5.setViewportView(MixedTable);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(35, Short.MAX_VALUE)
                .addComponent(scrollPane_add5, javax.swing.GroupLayout.PREFERRED_SIZE, 860, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(scrollPane_add5, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(422, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Mixed", jPanel6);

        jPanel7.setBackground(new java.awt.Color(204, 204, 255));

        CampingTable.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        CampingTable.setFont(new java.awt.Font("Tw Cen MT", 0, 14)); // NOI18N
        CampingTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tour Name", "How Many Day", "Capacity", "Price", "Date", "Image URL", "Camping Area"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Double.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        scrollPane_add.setViewportView(CampingTable);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(scrollPane_add, javax.swing.GroupLayout.PREFERRED_SIZE, 883, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(scrollPane_add, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(437, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Camping", jPanel7);

        panel_display.add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, -1, -1));

        jLabel54.setBackground(new java.awt.Color(204, 204, 255));
        jLabel54.setOpaque(true);
        panel_display.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1070, 980));

        tabbed_pane_admin.addTab("DISPLAY", panel_display);

        panel_edit.setFont(new java.awt.Font("Tw Cen MT", 0, 11)); // NOI18N
        panel_edit.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tf_tourName_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        panel_edit.add(tf_tourName_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 120, 119, -1));

        tf_capacity_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        panel_edit.add(tf_capacity_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 240, 119, -1));

        tf_price_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        panel_edit.add(tf_price_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 280, 119, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel13.setText("Tour Name: ");
        panel_edit.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel17.setText("Capacity: ");
        panel_edit.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, -1, -1));

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel18.setText("Price: ");
        panel_edit.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, -1, -1));

        bt_edit.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        bt_edit.setText("EDIT");
        bt_edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_editActionPerformed(evt);
            }
        });
        panel_edit.add(bt_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(87, 490, 80, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel2.setText("Tour Name: ");
        panel_edit.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 14, -1, -1));

        tf_tourName_search_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        panel_edit.add(tf_tourName_search_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 11, 119, -1));

        bt_search_edit.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        bt_search_edit.setText("SEARCH");
        bt_search_edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_search_editActionPerformed(evt);
            }
        });
        panel_edit.add(bt_search_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 42, -1, -1));

        ta_message_edit.setColumns(20);
        ta_message_edit.setFont(new java.awt.Font("Monospaced", 1, 14)); // NOI18N
        ta_message_edit.setRows(5);
        jScrollPane5.setViewportView(ta_message_edit);

        panel_edit.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 530, 227, 54));

        ta_search_result_edit.setColumns(20);
        ta_search_result_edit.setFont(new java.awt.Font("Monospaced", 1, 14)); // NOI18N
        ta_search_result_edit.setRows(5);
        jScrollPane6.setViewportView(ta_search_result_edit);

        panel_edit.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 263, 29));

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel19.setText("How Many Day:");
        panel_edit.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, -1, -1));

        tf_howManyDay_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        panel_edit.add(tf_howManyDay_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 200, 119, -1));

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel22.setText("New Start Date: ");
        panel_edit.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, -1, -1));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel23.setText("Tour Finish Date:");
        panel_edit.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, -1, -1));

        tf_tourFinishDate_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        panel_edit.add(tf_tourFinishDate_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 360, 119, -1));

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel25.setText("Tour Start Date: ");
        panel_edit.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, -1, -1));

        tf_tourStartDate_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        tf_tourStartDate_edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_tourStartDate_editActionPerformed(evt);
            }
        });
        panel_edit.add(tf_tourStartDate_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 320, 119, -1));

        jLabel26.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel26.setText("New Finish Date:");
        panel_edit.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, -1, -1));

        jLabel28.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel28.setText("Image URL: ");
        panel_edit.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, -1, -1));

        tf_imageURL_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        panel_edit.add(tf_imageURL_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 450, 119, -1));

        panel_card_edit.setLayout(new java.awt.CardLayout());

        panel_camping_edit.setBackground(new java.awt.Color(204, 204, 255));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel14.setText("Place To Camping Area: ");

        tf_placeToCampAr_camping_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        javax.swing.GroupLayout panel_camping_editLayout = new javax.swing.GroupLayout(panel_camping_edit);
        panel_camping_edit.setLayout(panel_camping_editLayout);
        panel_camping_editLayout.setHorizontalGroup(
            panel_camping_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_camping_editLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel14)
                .addGap(18, 18, 18)
                .addComponent(tf_placeToCampAr_camping_edit, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(93, Short.MAX_VALUE))
        );
        panel_camping_editLayout.setVerticalGroup(
            panel_camping_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_camping_editLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(panel_camping_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(tf_placeToCampAr_camping_edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(240, Short.MAX_VALUE))
        );

        panel_card_edit.add(panel_camping_edit, "card7");

        panel_cultural_edit.setBackground(new java.awt.Color(204, 204, 255));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel15.setText("City Name:");

        jLabel38.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel38.setText("Hotel Name: ");

        jLabel39.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel39.setText("Place To Visit: ");

        tf_cityName_cultural_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        tf_hotelName_cultural_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        tf_placeToVisit_cultural_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        javax.swing.GroupLayout panel_cultural_editLayout = new javax.swing.GroupLayout(panel_cultural_edit);
        panel_cultural_edit.setLayout(panel_cultural_editLayout);
        panel_cultural_editLayout.setHorizontalGroup(
            panel_cultural_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_cultural_editLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_cultural_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel38)
                    .addComponent(jLabel39)
                    .addComponent(jLabel15))
                .addGap(30, 30, 30)
                .addGroup(panel_cultural_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tf_cityName_cultural_edit, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tf_hotelName_cultural_edit)
                    .addComponent(tf_placeToVisit_cultural_edit, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(208, Short.MAX_VALUE))
        );

        panel_cultural_editLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {tf_cityName_cultural_edit, tf_hotelName_cultural_edit, tf_placeToVisit_cultural_edit});

        panel_cultural_editLayout.setVerticalGroup(
            panel_cultural_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_cultural_editLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(panel_cultural_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel_cultural_editLayout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel38))
                    .addGroup(panel_cultural_editLayout.createSequentialGroup()
                        .addComponent(tf_cityName_cultural_edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tf_hotelName_cultural_edit, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(1, 1, 1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panel_cultural_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel39)
                    .addComponent(tf_placeToVisit_cultural_edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(222, Short.MAX_VALUE))
        );

        panel_card_edit.add(panel_cultural_edit, "card6");

        panel_mixed_edit.setBackground(new java.awt.Color(204, 204, 255));

        jLabel40.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel40.setText("City Name:");

        jLabel41.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel41.setText("Place To Visit: ");

        tf_cityName_mixed_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        tf_placeToVisit_mixed_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        javax.swing.GroupLayout panel_mixed_editLayout = new javax.swing.GroupLayout(panel_mixed_edit);
        panel_mixed_edit.setLayout(panel_mixed_editLayout);
        panel_mixed_editLayout.setHorizontalGroup(
            panel_mixed_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_mixed_editLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_mixed_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel41)
                    .addComponent(jLabel40))
                .addGap(18, 18, 18)
                .addGroup(panel_mixed_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tf_cityName_mixed_edit, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tf_placeToVisit_mixed_edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(221, Short.MAX_VALUE))
        );

        panel_mixed_editLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {tf_cityName_mixed_edit, tf_placeToVisit_mixed_edit});

        panel_mixed_editLayout.setVerticalGroup(
            panel_mixed_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_mixed_editLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(panel_mixed_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel40)
                    .addComponent(tf_cityName_mixed_edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_mixed_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel41)
                    .addComponent(tf_placeToVisit_mixed_edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(235, Short.MAX_VALUE))
        );

        panel_card_edit.add(panel_mixed_edit, "card5");

        panel_natural_edit.setBackground(new java.awt.Color(204, 204, 255));

        jLabel42.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel42.setText("Bungalow Name: ");

        tf_bungalowName_natural_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        jLabel50.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel50.setText("Region:");

        tf_region_natural_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        tf_region_natural_edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_region_natural_editActionPerformed(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel21.setText("Place To Visit: ");

        tf_placeToVisit_natural_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        javax.swing.GroupLayout panel_natural_editLayout = new javax.swing.GroupLayout(panel_natural_edit);
        panel_natural_edit.setLayout(panel_natural_editLayout);
        panel_natural_editLayout.setHorizontalGroup(
            panel_natural_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_natural_editLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(panel_natural_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel50)
                    .addComponent(jLabel21)
                    .addComponent(jLabel42))
                .addGap(45, 45, 45)
                .addGroup(panel_natural_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tf_region_natural_edit)
                    .addComponent(tf_bungalowName_natural_edit, javax.swing.GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE)
                    .addComponent(tf_placeToVisit_natural_edit))
                .addContainerGap(173, Short.MAX_VALUE))
        );

        panel_natural_editLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {tf_bungalowName_natural_edit, tf_region_natural_edit});

        panel_natural_editLayout.setVerticalGroup(
            panel_natural_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_natural_editLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(panel_natural_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel42)
                    .addComponent(tf_bungalowName_natural_edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_natural_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel50)
                    .addComponent(tf_region_natural_edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_natural_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(tf_placeToVisit_natural_edit, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(151, Short.MAX_VALUE))
        );

        panel_card_edit.add(panel_natural_edit, "card4");

        panel_summer_edit.setBackground(new java.awt.Color(204, 204, 255));

        jLabel43.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel43.setText("Hotel Name: ");

        jLabel44.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel44.setText("Beach Name: ");

        jLabel45.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel45.setText("Region: ");

        tf_hotelName_summer_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        tf_beachName_summer_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        tf_region_summer_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        jLabel46.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel46.setText("Place to Visit: ");

        tf_placeToVisit_summer_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        javax.swing.GroupLayout panel_summer_editLayout = new javax.swing.GroupLayout(panel_summer_edit);
        panel_summer_edit.setLayout(panel_summer_editLayout);
        panel_summer_editLayout.setHorizontalGroup(
            panel_summer_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_summer_editLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_summer_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel45)
                    .addComponent(jLabel44)
                    .addComponent(jLabel46)
                    .addComponent(jLabel43))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 118, Short.MAX_VALUE)
                .addGroup(panel_summer_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tf_region_summer_edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tf_beachName_summer_edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tf_placeToVisit_summer_edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tf_hotelName_summer_edit, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(132, 132, 132))
        );

        panel_summer_editLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {tf_beachName_summer_edit, tf_hotelName_summer_edit, tf_placeToVisit_summer_edit, tf_region_summer_edit});

        panel_summer_editLayout.setVerticalGroup(
            panel_summer_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_summer_editLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(panel_summer_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel43)
                    .addComponent(tf_hotelName_summer_edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_summer_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel44)
                    .addComponent(tf_beachName_summer_edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_summer_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel45)
                    .addComponent(tf_region_summer_edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panel_summer_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel46)
                    .addComponent(tf_placeToVisit_summer_edit, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(122, Short.MAX_VALUE))
        );

        panel_card_edit.add(panel_summer_edit, "card3");

        panel_winter_edit.setBackground(new java.awt.Color(204, 204, 255));

        jLabel47.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel47.setText("Ski Resort Name: ");

        jLabel48.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel48.setText("Hotel name: ");

        tf_skiResortName_winter_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        tf_hotelName_winter_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        javax.swing.GroupLayout panel_winter_editLayout = new javax.swing.GroupLayout(panel_winter_edit);
        panel_winter_edit.setLayout(panel_winter_editLayout);
        panel_winter_editLayout.setHorizontalGroup(
            panel_winter_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_winter_editLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(panel_winter_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(panel_winter_editLayout.createSequentialGroup()
                        .addComponent(jLabel48)
                        .addGap(65, 65, 65)
                        .addComponent(tf_hotelName_winter_edit))
                    .addGroup(panel_winter_editLayout.createSequentialGroup()
                        .addComponent(jLabel47)
                        .addGap(34, 34, 34)
                        .addComponent(tf_skiResortName_winter_edit, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(196, Short.MAX_VALUE))
        );
        panel_winter_editLayout.setVerticalGroup(
            panel_winter_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_winter_editLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(panel_winter_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel47)
                    .addComponent(tf_skiResortName_winter_edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_winter_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel48)
                    .addComponent(tf_hotelName_winter_edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(237, Short.MAX_VALUE))
        );

        panel_card_edit.add(panel_winter_edit, "card2");

        panel_edit.add(panel_card_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 5, -1, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel16.setText("Tour Type: ");
        panel_edit.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, -1));

        tf_tourType_edit.setEditable(false);
        tf_tourType_edit.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        panel_edit.add(tf_tourType_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 160, 119, -1));
        panel_edit.add(dateChooser_start_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 390, 120, 20));
        panel_edit.add(dateChooser_finish_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 420, 120, -1));

        jLabel55.setBackground(new java.awt.Color(204, 204, 255));
        jLabel55.setOpaque(true);
        panel_edit.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1070, 980));

        tabbed_pane_admin.addTab("EDIT", panel_edit);

        panel_delete.setFont(new java.awt.Font("Tw Cen MT", 0, 11)); // NOI18N
        panel_delete.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tf_tourName_delete.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        panel_delete.add(tf_tourName_delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 30, 119, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel1.setText("Tour Name: ");
        panel_delete.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));

        bt_delete.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        bt_delete.setText("DELETE");
        bt_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_deleteActionPerformed(evt);
            }
        });
        panel_delete.add(bt_delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 320, -1, -1));

        bt_search_delete.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        bt_search_delete.setText("SEARCH");
        bt_search_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_search_deleteActionPerformed(evt);
            }
        });
        panel_delete.add(bt_search_delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 70, -1, -1));

        ta_search_result_delete.setColumns(20);
        ta_search_result_delete.setFont(new java.awt.Font("Microsoft YaHei", 0, 10)); // NOI18N
        ta_search_result_delete.setRows(5);
        jScrollPane3.setViewportView(ta_search_result_delete);

        panel_delete.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, 207, 181));

        ta_message_delete.setColumns(20);
        ta_message_delete.setFont(new java.awt.Font("Microsoft YaHei", 0, 10)); // NOI18N
        ta_message_delete.setRows(5);
        jScrollPane4.setViewportView(ta_message_delete);

        panel_delete.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 360, 207, -1));

        jLabel52.setBackground(new java.awt.Color(204, 204, 255));
        jLabel52.setOpaque(true);
        panel_delete.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1070, 980));

        tabbed_pane_admin.addTab("DELETE", panel_delete);

        panel_money.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ta_display_money.setColumns(20);
        ta_display_money.setFont(new java.awt.Font("Imprint MT Shadow", 0, 15)); // NOI18N
        ta_display_money.setRows(5);
        jScrollPane2.setViewportView(ta_display_money);

        panel_money.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, 500, 390));

        bt_show_money.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        bt_show_money.setText("SHOW");
        bt_show_money.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_show_moneyActionPerformed(evt);
            }
        });
        panel_money.add(bt_show_money, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 30, 180, 40));

        jLabel53.setBackground(new java.awt.Color(204, 204, 255));
        jLabel53.setOpaque(true);
        panel_money.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1070, 980));

        tabbed_pane_admin.addTab("MONEY", panel_money);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tabbed_pane_admin, javax.swing.GroupLayout.PREFERRED_SIZE, 1127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(tabbed_pane_admin)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bt_search_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_search_deleteActionPerformed
        String tour_name = tf_tourName_delete.getText();
        searched_tour_index_delete = admin1.searchTour(tour_name);
        if (searched_tour_index_delete != -1) { //if searched tour found
            bt_delete.setVisible(true);
            ta_message_delete.setVisible(true);
            ta_search_result_delete.setText("TOUR FOUNDED\n\n" + admin1.getAdmintours().get(searched_tour_index_delete));

        } else { //if searched tour_name did not find
            bt_delete.setVisible(false);
            ta_message_delete.setVisible(false);
            ta_search_result_delete.setText("YOU HAVE NOT GOT THIS TOUR NAME!");
        }
    }//GEN-LAST:event_bt_search_deleteActionPerformed

    private void bt_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_deleteActionPerformed
        //print message on ta, tour successfully deleted or not
        if (admin1.removeTour(searched_tour_index_delete)) {
            ta_message_delete.setText("DELETED");
        } else {
            ta_message_delete.setText("SEARCED TOUR WAS NOT DELETED");
        }
    }//GEN-LAST:event_bt_deleteActionPerformed

    private void bt_search_editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_search_editActionPerformed
        String temp_placeToVisit_edit = "";
        String tourType;
        String tour_name = tf_tourName_search_edit.getText();
        searched_tour_index_edit = admin1.searchTour(tour_name);

        //if tour found
        if (searched_tour_index_edit != -1) {
            bt_edit.setVisible(true);
            ta_message_edit.setVisible(true);
            ta_search_result_edit.setText("TOUR FOUNDED");

            //set all items in tour and tour types for printing on edit screen
            tf_tourName_edit.setText(admin1.getAdmintours().get(searched_tour_index_edit).getTourName());
            tf_howManyDay_edit.setText(String.valueOf(admin1.getAdmintours().get(searched_tour_index_edit).getHowManyDay()));
            tf_capacity_edit.setText(String.valueOf(admin1.getAdmintours().get(searched_tour_index_edit).getCapacity()));
            tf_price_edit.setText(String.valueOf(admin1.getAdmintours().get(searched_tour_index_edit).getPrice()));

            if (admin1.getAdmintours().get(searched_tour_index_edit) instanceof CulturalTour) {
                tourType = "Cultural";
                //if we want to access subclass's functions, we should create an object in that subclass
                CulturalTour cp;
                cp = (CulturalTour) admin1.getAdmintours().get(searched_tour_index_edit);
                tf_cityName_cultural_edit.setText(cp.getCityName());
                tf_hotelName_cultural_edit.setText(cp.getHotelName());
                //cultural tour information should visible for printing values
                panel_card_edit.setVisible(true);
                panel_camping_edit.setVisible(false);
                panel_cultural_edit.setVisible(true);
                panel_mixed_edit.setVisible(false);
                panel_natural_edit.setVisible(false);
                panel_summer_edit.setVisible(false);
                panel_winter_edit.setVisible(false);
            } else if (admin1.getAdmintours().get(searched_tour_index_edit) instanceof SummerTour) {
                tourType = "Summer";
                //if we want to access subclass's functions, we should create an object in that subclass
                SummerTour sp;
                sp = (SummerTour) admin1.getAdmintours().get(searched_tour_index_edit);
                tf_hotelName_summer_edit.setText(sp.getHotelName());
                tf_beachName_summer_edit.setText(sp.getBeachName());
                tf_region_summer_edit.setText(sp.getRegion());
                tf_placeToVisit_summer_edit.setText(sp.getPlace_to_visit());
                //summer tour information should visible for printing values
                panel_card_edit.setVisible(true);
                panel_camping_edit.setVisible(false);
                panel_cultural_edit.setVisible(false);
                panel_mixed_edit.setVisible(false);
                panel_natural_edit.setVisible(false);
                panel_summer_edit.setVisible(true);
                panel_winter_edit.setVisible(false);
            } else if (admin1.getAdmintours().get(searched_tour_index_edit) instanceof WinterTour) {
                tourType = "Winter";
                //if we want to access subclass's functions, we should create an object in that subclass
                WinterTour wp;
                wp = (WinterTour) admin1.getAdmintours().get(searched_tour_index_edit);
                tf_hotelName_winter_edit.setText(wp.getHotelName());
                tf_skiResortName_winter_edit.setText(wp.getSkiResortName());
                //winter tour information should visible for printing values
                panel_card_edit.setVisible(true);
                panel_camping_edit.setVisible(false);
                panel_cultural_edit.setVisible(false);
                panel_mixed_edit.setVisible(false);
                panel_natural_edit.setVisible(false);
                panel_summer_edit.setVisible(false);
                panel_winter_edit.setVisible(true);
            } else if (admin1.getAdmintours().get(searched_tour_index_edit) instanceof MixedTour) {
                tourType = "Mixed";
                //if we want to access subclass's functions, we should create an object in that subclass
                MixedTour mp;
                mp = (MixedTour) admin1.getAdmintours().get(searched_tour_index_edit);
                tf_cityName_mixed_edit.setText(mp.getCityName());
                tf_placeToVisit_mixed_edit.setText(mp.getPlace_to_visit());
                //mixed tour information should visible for printing values
                panel_card_edit.setVisible(true);
                panel_camping_edit.setVisible(false);
                panel_cultural_edit.setVisible(false);
                panel_mixed_edit.setVisible(true);
                panel_natural_edit.setVisible(false);
                panel_summer_edit.setVisible(false);
                panel_winter_edit.setVisible(false);
            } else if (admin1.getAdmintours().get(searched_tour_index_edit) instanceof CampingTour) {
                tourType = "Camping";
                //if we want to access subclass's functions, we should create an object in that subclass
                CampingTour cp;
                cp = (CampingTour) admin1.getAdmintours().get(searched_tour_index_edit);
                tf_placeToCampAr_camping_edit.setText(cp.getPlaceToCampingArea());
                //camping tour information should visible for printing values
                panel_card_edit.setVisible(true);
                panel_camping_edit.setVisible(true);
                panel_cultural_edit.setVisible(false);
                panel_mixed_edit.setVisible(false);
                panel_natural_edit.setVisible(false);
                panel_summer_edit.setVisible(false);
                panel_winter_edit.setVisible(false);
            } else if (admin1.getAdmintours().get(searched_tour_index_edit) instanceof NaturalTour) {
                tourType = "Natural";
                //if we want to access subclass's functions, we should create an object in that subclass
                NaturalTour np;
                np = (NaturalTour) admin1.getAdmintours().get(searched_tour_index_edit);
                tf_bungalowName_natural_edit.setText(np.getBungalovName());
                tf_region_natural_edit.setText(np.getRegion());
                tf_placeToVisit_natural_edit.setText(np.getPlace_to_visit());
                //natural tour information should visible for printing values
                panel_card_edit.setVisible(true);
                panel_camping_edit.setVisible(false);
                panel_cultural_edit.setVisible(false);
                panel_mixed_edit.setVisible(false);
                panel_natural_edit.setVisible(true);
                panel_summer_edit.setVisible(false);
                panel_winter_edit.setVisible(false);
            } else { //tour type is different than this 6 tour types
                tourType = "Not Founded";
            }
            tf_tourType_edit.setText(tourType);
            //print founded tour's date in dd-mm-yyyy format on edit screen
            tf_tourStartDate_edit.setText(admin1.getAdmintours().get(searched_tour_index_edit).getFirst_day() + "-"
                    + admin1.getAdmintours().get(searched_tour_index_edit).getFirst_month() + "-"
                    + admin1.getAdmintours().get(searched_tour_index_edit).getFirst_year());
            tf_tourFinishDate_edit.setText(admin1.getAdmintours().get(searched_tour_index_edit).getLast_day() + "-"
                    + admin1.getAdmintours().get(searched_tour_index_edit).getLast_month() + "-"
                    + admin1.getAdmintours().get(searched_tour_index_edit).getLast_year());
            tf_imageURL_edit.setText(admin1.getAdmintours().get(searched_tour_index_edit).getImageURL());

        } else { //if tour didn't find
            bt_edit.setVisible(false);
            ta_message_edit.setVisible(false);
            ta_search_result_edit.setText("YOU HAVE NOT GOT THIS TOUR NAME!");
        }
    }//GEN-LAST:event_bt_search_editActionPerformed

    private void bt_editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_editActionPerformed
        String tour_name = tf_tourName_search_edit.getText();
        searched_tour_index_edit = admin1.searchTour(tour_name);
        if (searched_tour_index_edit != -1) { //if tour founded, delete it
            admin1.removeTour(searched_tour_index_edit);
            //admin1.getAdmintours().remove(admin1.getAdmintours().get(searched_tour_index_edit));
        }
        //when admin want to edit tour on admin's edit panel, all fields about selected tour type should filled. 
        //We want to show error message when all fields did not fill. For this reason we need try-catch.
        try {
            //get all needed values for editing new tour
            String tourName = tf_tourName_edit.getText();
            String howManyDay = tf_howManyDay_edit.getText();
            int capacity = Integer.parseInt(tf_capacity_edit.getText());
            double price = Double.parseDouble(tf_price_edit.getText());
            String imageUrl = tf_imageURL_edit.getText();

            dateChooser_start_edit.setFont(new Font("Tahoma", Font.PLAIN, 12));
            dateChooser_start_edit.setDateFormatString("dd-MM-yyyy");
            DateFormat df_first_edit = new SimpleDateFormat("dd-MM-yyyy");

            String s_firstDate_edit = df_first_edit.format(dateChooser_start_edit.getDate());
            String[] temp_firstDate_edit = s_firstDate_edit.split("-");
            int first_day_edit = Integer.parseInt(temp_firstDate_edit[0]);
            int first_month_edit = Integer.parseInt(temp_firstDate_edit[1]);
            int first_year_edit = Integer.parseInt(temp_firstDate_edit[2]);

            dateChooser_start_edit.setFont(new Font("Tahoma", Font.PLAIN, 12));
            dateChooser_start_edit.setDateFormatString("dd-MM-yyyy");
            DateFormat df_last_edit = new SimpleDateFormat("dd-MM-yyyy");

            String s_lastDate_edit = df_last_edit.format(dateChooser_start_edit.getDate());
            String[] temp_lastDate_edit = s_lastDate_edit.split("-");
            int last_day_add = Integer.parseInt(temp_lastDate_edit[0]);
            int last_month_add = Integer.parseInt(temp_lastDate_edit[1]);
            int last_year_add = Integer.parseInt(temp_lastDate_edit[2]);

            if (tf_tourType_edit.getText().equalsIgnoreCase("Camping")) {

                String new_placeToCampingArea = tf_placeToCampAr_camping_edit.getText();
                CampingTour ct = new CampingTour(new_placeToCampingArea, tourName, howManyDay, capacity, price, first_day_edit, first_month_edit, first_year_edit, last_day_add, last_month_add, last_year_add, imageUrl);
                admin1.getAdmintours().add(searched_tour_index_edit, ct);
                ta_message_edit.setText("Camping tour editted successfully");
            } else if (tf_tourType_edit.getText().equalsIgnoreCase("Cultural")) {

                String hotelName_edit = tf_hotelName_cultural_edit.getText();
                String cityName_edit = tf_cityName_cultural_edit.getText();
                String placeToVisit = tf_placeToVisit_cultural_edit.getText();

                CulturalTour ct = new CulturalTour(tourName, tourName, placeToVisit, tourName, howManyDay, capacity, price, first_day_edit, first_month_edit, first_year_edit, last_day_add, last_month_add, last_year_add, imageUrl);

                admin1.getAdmintours().add(searched_tour_index_edit, ct);
                ta_message_edit.setText("Cultural tour editted successfully");
            } else if (tf_tourType_edit.getText().equalsIgnoreCase("Mixed")) {

                String cityName_edit = tf_cityName_cultural_edit.getText();
                String placeToVisit = tf_placeToVisit_cultural_edit.getText();
                MixedTour mt = new MixedTour(tourName, placeToVisit, tourName, howManyDay, capacity, price, first_day_edit, first_month_edit, first_year_edit, last_day_add, last_month_add, last_year_add, imageUrl);
                admin1.getAdmintours().add(searched_tour_index_edit, mt);
                ta_message_edit.setText("Mixed tour editted successfully");
            } else if (tf_tourType_edit.getText().equalsIgnoreCase("Natural")) {

                String bungalowName_edit = tf_bungalowName_natural_edit.getText();
                String region_edit = tf_region_natural_edit.getText();
                String placeToVisit = tf_placeToVisit_natural_edit.getText();
                NaturalTour nt = new NaturalTour(bungalowName_edit, region_edit, placeToVisit, tourName, howManyDay, capacity, price, first_day_edit, first_month_edit, first_year_edit, last_day_add, last_month_add, last_year_add, imageUrl);
                admin1.getAdmintours().add(searched_tour_index_edit, nt);
                ta_message_edit.setText("Natural tour editted successfully");
            } else if (tf_tourType_edit.getText().equalsIgnoreCase("Summer")) {
                String beachName_edit = tf_beachName_summer_edit.getText();
                String hotelName_edit = tf_hotelName_summer_edit.getText();
                String region_edit = tf_region_summer_edit.getText();
                String placeToVisit = tf_placeToVisit_natural_edit.getText();

                SummerTour st = new SummerTour(tourName, beachName_edit, region_edit, placeToVisit, tourName, howManyDay, capacity, price, first_day_edit, first_month_edit, first_year_edit, last_day_add, last_month_add, last_year_add, imageUrl);
                admin1.getAdmintours().add(searched_tour_index_edit, st);
                ta_message_edit.setText("Summer tour editted successfully");
            } else if (tf_tourType_edit.getText().equalsIgnoreCase("Winter")) {
                String skiResortName = tf_skiResortName_winter_edit.getText();
                String hotelName_edit = tf_hotelName_winter_edit.getText();

                WinterTour wt = new WinterTour(skiResortName, tourName, tourName, howManyDay, capacity, price, first_day_edit, first_month_edit, first_year_edit, last_day_add, last_month_add, last_year_add, imageUrl);
                admin1.getAdmintours().add(searched_tour_index_edit, wt);
                ta_message_edit.setText("Winter tour editted successfully");
            } else {
                JOptionPane.showMessageDialog(null, "hata", "try again", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "All fields should be filled correctly!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bt_editActionPerformed

    private void bt_displayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_displayActionPerformed
        //show all tours on table where admin's display frame
        //we want to seperate tour types when showing tours because of easy to use and good appearance
        String date = "";
        String[] temp;

        DefaultTableModel model_culturel = (DefaultTableModel) CulturalTable.getModel();
        model_culturel.setRowCount(0);

        DefaultTableModel model_camping = (DefaultTableModel) CampingTable.getModel();
        model_camping.setRowCount(0);

        DefaultTableModel model_mixed = (DefaultTableModel) MixedTable.getModel();
        model_mixed.setRowCount(0);

        DefaultTableModel model_natural = (DefaultTableModel) NaturalTable.getModel();
        model_natural.setRowCount(0);

        DefaultTableModel model_summer = (DefaultTableModel) SummerTable.getModel();
        model_summer.setRowCount(0);

        DefaultTableModel model_winter = (DefaultTableModel) WinterTable.getModel();
        model_winter.setRowCount(0);

        for (int i = 0; i < admin1.getAdmintours().size(); i++) {

            //convert int day,month,year to string with form dd.mm.yyyy-dd.mm.yyyy for easy to print and better appearance 
            date = admin1.getAdmintours().get(i).getFirst_day() + "."
                    + admin1.getAdmintours().get(i).getFirst_month() + "."
                    + admin1.getAdmintours().get(i).getFirst_year() + " - "
                    + admin1.getAdmintours().get(i).getLast_day() + "."
                    + admin1.getAdmintours().get(i).getLast_month() + "."
                    + admin1.getAdmintours().get(i).getLast_year();

            if (admin1.getAdmintours().get(i) instanceof CulturalTour) {
                //we need creating subclass object for using subclass' methods
                CulturalTour ct;
                ct = (CulturalTour) admin1.getAdmintours().get(i);

                temp = ct.getPlace_to_visit().split(",");

                model_culturel.addRow(new Object[]{
                    admin1.getAdmintours().get(i).getTourName(),
                    admin1.getAdmintours().get(i).getHowManyDay(),
                    admin1.getAdmintours().get(i).getCapacity(),
                    admin1.getAdmintours().get(i).getPrice(),
                    date,
                    admin1.getAdmintours().get(i).getImageURL(),
                    ct.getHotelName(),
                    ct.getCityName(),
                    temp[0],});//ct.getPlace_to_visit(),
                for (int j = 1; j < temp.length; j++) {
                    model_culturel.setRowCount(j);
                    model_culturel.addRow(new Object[]{
                        "",
                        null,
                        null,
                        null,
                        "",
                        "",
                        "",
                        "",
                        temp[j],});

                }

            } else if (admin1.getAdmintours().get(i) instanceof WinterTour) {
                WinterTour wt;
                wt = (WinterTour) admin1.getAdmintours().get(i);

                model_winter.addRow(new Object[]{
                    admin1.getAdmintours().get(i).getTourName(),
                    admin1.getAdmintours().get(i).getHowManyDay(),
                    admin1.getAdmintours().get(i).getCapacity(),
                    admin1.getAdmintours().get(i).getPrice(),
                    date,
                    admin1.getAdmintours().get(i).getImageURL(),
                    wt.getSkiResortName(),
                    wt.getHotelName(),});

            } else if (admin1.getAdmintours().get(i) instanceof MixedTour) {
                MixedTour mt;
                mt = (MixedTour) admin1.getAdmintours().get(i);

                temp = mt.getPlace_to_visit().split(",");

                model_mixed.addRow(new Object[]{
                    admin1.getAdmintours().get(i).getTourName(),
                    admin1.getAdmintours().get(i).getHowManyDay(),
                    admin1.getAdmintours().get(i).getCapacity(),
                    admin1.getAdmintours().get(i).getPrice(),
                    date,
                    admin1.getAdmintours().get(i).getImageURL(),
                    mt.getCityName(),
                    temp[0],});
                for (int j = 1; j < temp.length; j++) {
                    model_mixed.setRowCount(j);
                    model_mixed.addRow(new Object[]{
                        "",
                        null,
                        null,
                        null,
                        "",
                        "",
                        "",
                        temp[j],});

                }
            } else if (admin1.getAdmintours().get(i) instanceof NaturalTour) {
                NaturalTour ct;
                ct = (NaturalTour) admin1.getAdmintours().get(i);

                temp = ct.getPlace_to_visit().split(",");

                model_natural.addRow(new Object[]{
                    admin1.getAdmintours().get(i).getTourName(),
                    admin1.getAdmintours().get(i).getHowManyDay(),
                    admin1.getAdmintours().get(i).getCapacity(),
                    admin1.getAdmintours().get(i).getPrice(),
                    date,
                    admin1.getAdmintours().get(i).getImageURL(),
                    ct.getBungalovName(),
                    ct.getRegion(),
                    temp[0],});
                for (int j = 1; j < temp.length; j++) {
                    model_natural.setRowCount(j);
                    model_natural.addRow(new Object[]{
                        "",
                        null,
                        null,
                        null,
                        "",
                        "",
                        "",
                        "",
                        temp[j],});
                }
            } else if (admin1.getAdmintours().get(i) instanceof SummerTour) {
                SummerTour st;
                st = (SummerTour) admin1.getAdmintours().get(i);

                temp = st.getPlace_to_visit().split(",");

                model_summer.addRow(new Object[]{
                    admin1.getAdmintours().get(i).getTourName(),
                    admin1.getAdmintours().get(i).getHowManyDay(),
                    admin1.getAdmintours().get(i).getCapacity(),
                    admin1.getAdmintours().get(i).getPrice(),
                    date,
                    admin1.getAdmintours().get(i).getImageURL(),
                    st.getHotelName(),
                    st.getBeachName(),
                    st.getRegion(),
                    temp[0],});
                for (int j = 1; j < temp.length; j++) {
                    model_summer.setRowCount(j);
                    model_summer.addRow(new Object[]{
                        "",
                        null,
                        null,
                        null,
                        "",
                        "",
                        "",
                        "",
                        "",
                        temp[j],});
                }
            } else if (admin1.getAdmintours().get(i) instanceof CampingTour) {
                CampingTour cp;
                cp = (CampingTour) admin1.getAdmintours().get(i);
                model_camping.addRow(new Object[]{
                    admin1.getAdmintours().get(i).getTourName(),
                    admin1.getAdmintours().get(i).getHowManyDay(),
                    admin1.getAdmintours().get(i).getCapacity(),
                    admin1.getAdmintours().get(i).getPrice(),
                    date,
                    admin1.getAdmintours().get(i).getImageURL(),
                    cp.getPlaceToCampingArea(),});
            } else {
                JOptionPane.showMessageDialog(null, "hata", "try again", JOptionPane.ERROR_MESSAGE);
            }
        }

    }//GEN-LAST:event_bt_displayActionPerformed

    private void bt_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_addActionPerformed
        int k = admin1.getAdmintours().size();  //k holds admin1's number of tour
        //when admin want to add new tour on admin's add panel, all fields about selected tour type should filled. 
        //We want to show error message when all fields did not fill. For this reason we need try-catch.
        try {
            //get all needed values for adding new tour
            String tourName_add = tf_tourName_add.getText();
            String howManyDay = tf_howManyDay.getText();

            int capacity = Integer.parseInt(tf_capacity_add.getText());
            double price = Double.parseDouble(tf_price_add.getText());

            dateChooser_first_add.setFont(new Font("Tahoma", Font.PLAIN, 12));
            dateChooser_first_add.setDateFormatString("dd-MM-yyyy");
            DateFormat df_first_add = new SimpleDateFormat("dd-MM-yyyy");

            String s_firstDate_add = df_first_add.format(dateChooser_first_add.getDate());
            String[] temp_firstDate_add = s_firstDate_add.split("-");
            int first_day_add = Integer.parseInt(temp_firstDate_add[0]);
            int first_month_add = Integer.parseInt(temp_firstDate_add[1]);
            int first_year_add = Integer.parseInt(temp_firstDate_add[2]);

            dateChooser_last_add.setFont(new Font("Tahoma", Font.PLAIN, 12));
            dateChooser_last_add.setDateFormatString("dd-MM-yyyy");
            DateFormat df_last_add = new SimpleDateFormat("dd-MM-yyyy");

            String s_lastDate_add = df_last_add.format(dateChooser_last_add.getDate());
            String[] temp_lastDate_add = s_lastDate_add.split("-");
            int last_day_add = Integer.parseInt(temp_lastDate_add[0]);
            int last_month_add = Integer.parseInt(temp_lastDate_add[1]);
            int last_year_add = Integer.parseInt(temp_lastDate_add[2]);

            String imageURL_add = tf_imageURL_add.getText();

            if (admin1.searchTour(tourName_add) != -1) {
                ta_message_add.setText("YOU HAVE THIS TOUR NAME(" + tourName_add + ")!\nPLEASE SELECT ANOTHER TOUR NAME\n");
            } else {//if we have different tour name
                //clear all texfields for security and making useful for admin
                tf_tourName_add.setText("");
                tf_howManyDay.setText("");
                tf_capacity_add.setText("");
                tf_price_add.setText("");
                //dateChooser_first_add.setDateFormatString("");
                //dateChooser_last_add.setDateFormatString("");
                tf_imageURL_add.setText("");

                if (comboBox_add.getSelectedItem().toString().equalsIgnoreCase("Camping")) {

                    String placeToCamA_add = tf_placeToCampAr_camping_add.getText();
                    tf_placeToCampAr_camping_add.setText("");

                    CampingTour ct = new CampingTour(placeToCamA_add, tourName_add, howManyDay, capacity, price, first_day_add, first_month_add, first_year_add, last_day_add, last_month_add, last_year_add, imageURL_add);
                    admin1.addTour(ct);
                    if (k + 1 == admin1.getAdmintours().size()) {  //size + 1 == admin1.getAdmintours().size()
                        ta_message_add.setText("TOUR ADDED SUCCESSFULLY");
                        //write added tour on file "SEHIRbelgesi.txt" for keeping data and using that datas for exit the program
                        try {
                            BufferedWriter writer = new BufferedWriter(new FileWriter("SEHIRbelgesi.txt", true));

                            writer.write("Camping" + "\n");
                            writer.write(tourName_add + "\n");
                            writer.write(howManyDay + "\n");
                            writer.write((int) (price) + "\n");
                            writer.write(capacity + "\n");
                            writer.write(first_day_add + "-" + first_month_add + "-" + first_year_add + "\n");
                            writer.write(last_day_add + "-" + last_month_add + "-" + last_year_add + "\n");
                            writer.write(imageURL_add + "\n");
                            writer.write(placeToCamA_add + "\n");
                            writer.close();
                        } catch (Exception e) {
                        }

                        k++;
                    }

                } else if (comboBox_add.getSelectedItem().toString().equalsIgnoreCase("Cultural")) {

                    String hotelName_add = tf_hotelName_cultural_add.getText();
                    String cityName_add = tf_cityName_cultural_add.getText();
                    String placeToVisit = tf_placeToVisit_cultural_add.getText();

                    if (hotelName_add.equalsIgnoreCase("") || cityName_add.equalsIgnoreCase("") || placeToVisit.equalsIgnoreCase("")) {
                        JOptionPane.showMessageDialog(null, "All fields should be filled correctly!", "Error", JOptionPane.ERROR_MESSAGE);
                        panel_card_add.setVisible(true);
                        panel_cultural_add.setVisible(true);
                    } else {

                        tf_hotelName_cultural_add.setText("");
                        tf_cityName_cultural_add.setText("");
                        tf_placeToVisit_cultural_add.setText("");

                        CulturalTour ct = new CulturalTour(hotelName_add, cityName_add, placeToVisit, tourName_add, howManyDay, capacity, price, first_day_add, first_month_add, first_year_add, last_day_add, last_month_add, last_year_add, imageURL_add);
                        admin1.addTour(ct);

                        if (k + 1 == admin1.getAdmintours().size()) {
                            ta_message_add.setText("TOUR ADDED SUCCESSFULLY");
                            try {
                                BufferedWriter writer = new BufferedWriter(new FileWriter("SEHIRbelgesi.txt", true));

                                writer.write("Cultural" + "\n");
                                writer.write(tourName_add + "\n");
                                writer.write(howManyDay + "\n");
                                writer.write(capacity + "\n");
                                writer.write((int) (price) + "\n");
                                writer.write(first_day_add + "-" + first_month_add + "-" + first_year_add + "\n");
                                writer.write(last_day_add + "-" + last_month_add + "-" + last_year_add + "\n");
                                writer.write(imageURL_add + "\n");
                                writer.write(hotelName_add + "\n");
                                writer.write(cityName_add + "\n");
                                writer.write(placeToVisit + "\n");
                                writer.close();
                            } catch (Exception e) {
                            }

                            k++;
                        }
                    }
                } else if (comboBox_add.getSelectedItem().toString().equalsIgnoreCase("Mixed")) {

                    String cityName_add = tf_cityName_mixed_add.getText();
                    String placeToVisit = tf_placeToVisit_mixed_add.getText();

                    if (cityName_add.equalsIgnoreCase("") || placeToVisit.equalsIgnoreCase("")) {
                        JOptionPane.showMessageDialog(null, "All fields should be filled correctly!", "Error", JOptionPane.ERROR_MESSAGE);
                        panel_card_add.setVisible(true);
                        panel_mixed_add.setVisible(true);
                    } else {

                        tf_cityName_mixed_add.setText("");
                        tf_placeToVisit_mixed_add.setText("");

                        MixedTour mt = new MixedTour(cityName_add, placeToVisit, tourName_add, howManyDay, capacity, price, first_day_add, first_month_add, first_year_add, last_day_add, last_month_add, last_year_add, imageURL_add);
                        admin1.addTour(mt);

                        if (k + 1 == admin1.getAdmintours().size()) {
                            ta_message_add.setText("TOUR ADDED SUCCESSFULLY");
                            try {
                                BufferedWriter writer = new BufferedWriter(new FileWriter("SEHIRbelgesi.txt", true));

                                writer.write("Mixed" + "\n");
                                writer.write(tourName_add + "\n");
                                writer.write(howManyDay + "\n");
                                writer.write(capacity + "\n");
                                writer.write((int) (price) + "\n");
                                writer.write(first_day_add + "-" + first_month_add + "-" + first_year_add + "\n");
                                writer.write(last_day_add + "-" + last_month_add + "-" + last_year_add + "\n");
                                writer.write(imageURL_add + "\n");
                                writer.write(cityName_add + "\n");
                                writer.write(placeToVisit + "\n");
                                writer.close();
                            } catch (Exception e) {
                            }
                            k++;
                        }
                    }
                } else if (comboBox_add.getSelectedItem().toString().equalsIgnoreCase("Natural")) {

                    String bungalowName_add = tf_bungalowName_natural_add.getText();
                    String region_add = tf_region_natural_add.getText();
                    String placeToVisit = tf_placeToVisit_natural_add.getText();

                    if (bungalowName_add.equalsIgnoreCase("") || region_add.equalsIgnoreCase("") || placeToVisit.equalsIgnoreCase("")) {
                        JOptionPane.showMessageDialog(null, "All fields should be filled correctly!", "Error", JOptionPane.ERROR_MESSAGE);
                        panel_card_add.setVisible(true);
                        panel_natural_add.setVisible(true);
                    } else {

                        tf_bungalowName_natural_add.setText("");
                        tf_region_natural_add.setText("");
                        tf_placeToVisit_natural_add.setText("");

                        NaturalTour nt = new NaturalTour(bungalowName_add, region_add, placeToVisit, tourName_add, howManyDay, capacity, price, first_day_add, first_month_add, first_year_add, last_day_add, last_month_add, last_year_add, imageURL_add);
                        admin1.addTour(nt);

                        if (k + 1 == admin1.getAdmintours().size()) {
                            ta_message_add.setText("TOUR ADDED SUCCESSFULLY");
                            try {
                                BufferedWriter writer = new BufferedWriter(new FileWriter("SEHIRbelgesi.txt", true));

                                writer.write("Natural" + "\n");
                                writer.write(tourName_add + "\n");
                                writer.write(howManyDay + "\n");
                                writer.write(capacity + "\n");
                                writer.write((int) (price) + "\n");
                                writer.write(first_day_add + "-" + first_month_add + "-" + first_year_add + "\n");
                                writer.write(last_day_add + "-" + last_month_add + "-" + last_year_add + "\n");
                                writer.write(imageURL_add + "\n");
                                writer.write(bungalowName_add + "\n");
                                writer.write(placeToVisit + "\n");
                                writer.write(region_add + "\n");
                                writer.close();
                            } catch (Exception e) {
                            }
                            k++;
                        }
                    }
                } else if (comboBox_add.getSelectedItem().toString().equalsIgnoreCase("Summer")) {

                    String beachName_add = tf_beachName_summer_add.getText();
                    String hotelName_add = tf_hıtelNAme_summer_add.getText();
                    String region_add = tf_region_summer_add.getText();
                    String placeToVisit = tf_placeToVisit_summer_add.getText();

                    if (beachName_add.equalsIgnoreCase("") || hotelName_add.equalsIgnoreCase("") || region_add.equalsIgnoreCase("") || placeToVisit.equalsIgnoreCase("")) {
                        JOptionPane.showMessageDialog(null, "All fields should be filled correctly!", "Error", JOptionPane.ERROR_MESSAGE);
                        panel_card_add.setVisible(true);
                        panel_summer_add.setVisible(true);
                    } else {

                        tf_beachName_summer_add.setText("");
                        tf_hıtelNAme_summer_add.setText("");
                        tf_region_summer_add.setText("");
                        tf_placeToVisit_summer_add.setText("");

                        SummerTour st = new SummerTour(hotelName_add, beachName_add, region_add, placeToVisit, tourName_add, howManyDay, capacity, price, first_day_add, first_month_add, first_year_add, last_day_add, last_month_add, last_year_add, imageURL_add);

                        admin1.addTour(st);

                        if (k + 1 == admin1.getAdmintours().size()) {
                            ta_message_add.setText("TOUR ADDED SUCCESSFULLY");
                            try {
                                BufferedWriter writer = new BufferedWriter(new FileWriter("SEHIRbelgesi.txt", true));

                                writer.write("Summer" + "\n");

                                writer.write(tourName_add + "\n");
                                writer.write(howManyDay + "\n");
                                writer.write((int) (price) + "\n");
                                writer.write(capacity + "\n");
                                writer.write(first_day_add + "-" + first_month_add + "-" + first_year_add + "\n");
                                writer.write(last_day_add + "-" + last_month_add + "-" + last_year_add + "\n");
                                writer.write(imageURL_add + "\n");
                                writer.write(hotelName_add + "\n");
                                writer.write(beachName_add + "\n");
                                writer.write(region_add + "\n");
                                writer.write(placeToVisit + "\n");
                                writer.close();
                            } catch (Exception e) {
                            }
                            k++;
                        }
                    }
                } else if (comboBox_add.getSelectedItem().toString().equalsIgnoreCase("Winter")) {

                    String skiResortName = tf_skiResortName_winter_add.getText();
                    String hotelName_add = tf_hotelName_winter_add.getText();

                    if (skiResortName.equalsIgnoreCase("") || hotelName_add.equalsIgnoreCase("")) {
                        JOptionPane.showMessageDialog(null, "All fields should be filled correctly!", "Error", JOptionPane.ERROR_MESSAGE);
                        panel_card_add.setVisible(true);
                        panel_winter_add.setVisible(true);
                    } else {

                        tf_skiResortName_winter_add.setText("");
                        tf_hotelName_winter_add.setText("");

                        WinterTour wt = new WinterTour(skiResortName, hotelName_add, tourName_add, howManyDay, capacity, price, first_day_add, first_month_add, first_year_add, last_day_add, last_month_add, last_year_add, imageURL_add);

                        admin1.addTour(wt);

                        if (k + 1 == admin1.getAdmintours().size()) {
                            ta_message_add.setText("TOUR ADDED SUCCESSFULLY");
                            try {
                                BufferedWriter writer = new BufferedWriter(new FileWriter("SEHIRbelgesi.txt", true));
                                writer.write("Winter\n");

                                writer.write(tourName_add + "\n");
                                writer.write(howManyDay + "\n");
                                writer.write((int) (price) + "\n");
                                writer.write(capacity + "\n");
                                writer.write(first_day_add + "-" + first_month_add + "-" + first_year_add + "\n");
                                writer.write(last_day_add + "-" + last_month_add + "-" + last_year_add + "\n");
                                writer.write(imageURL_add + "\n");
                                writer.write(hotelName_add + "\n");
                                writer.write(skiResortName + "\n");
                                writer.close();
                            } catch (Exception e) {
                            }
                            k++;
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "hata", "try again", JOptionPane.ERROR_MESSAGE);
                }

                panel_card_add.setVisible(false);
                panel_camping_add.setVisible(false);
                panel_cultural_add.setVisible(false);
                panel_mixed_add.setVisible(false);
                panel_natural_add.setVisible(false);
                panel_summer_add.setVisible(false);
                panel_winter_add.setVisible(false);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "All fields should be filled correctly!", "Error", JOptionPane.ERROR_MESSAGE);
        }
        try {

            BufferedWriter writer = new BufferedWriter(new FileWriter("SEHIRbelgesi.txt", true));
            writer.write("\n");
            writer.close();
        } catch (Exception e) {
        }

    }//GEN-LAST:event_bt_addActionPerformed

    private void tf_tourStartDate_editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_tourStartDate_editActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tf_tourStartDate_editActionPerformed

    private void tf_bungalowName_natural_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_bungalowName_natural_addActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tf_bungalowName_natural_addActionPerformed

    private void tf_region_natural_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_region_natural_addActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tf_region_natural_addActionPerformed

    private void comboBox_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBox_addActionPerformed
        //when tour type selected on comboBox, releated panels should be visible
        //releated panels are card_panel and selectedTourType_panel
        if (comboBox_add.getSelectedItem().toString().equalsIgnoreCase("Camping")) {
            panel_card_add.setVisible(true);
            panel_camping_add.setVisible(true);
            panel_cultural_add.setVisible(false);
            panel_mixed_add.setVisible(false);
            panel_natural_add.setVisible(false);
            panel_summer_add.setVisible(false);
            panel_winter_add.setVisible(false);
        } else if (comboBox_add.getSelectedItem().toString().equalsIgnoreCase("Summer")) {
            panel_card_add.setVisible(true);
            panel_camping_add.setVisible(false);
            panel_cultural_add.setVisible(false);
            panel_mixed_add.setVisible(false);
            panel_natural_add.setVisible(false);
            panel_summer_add.setVisible(true);
            panel_winter_add.setVisible(false);
        } else if (comboBox_add.getSelectedItem().toString().equalsIgnoreCase("Winter")) {
            panel_card_add.setVisible(true);
            panel_camping_add.setVisible(false);
            panel_cultural_add.setVisible(false);
            panel_mixed_add.setVisible(false);
            panel_natural_add.setVisible(false);
            panel_summer_add.setVisible(false);
            panel_winter_add.setVisible(true);
        } else if (comboBox_add.getSelectedItem().toString().equalsIgnoreCase("Natural")) {
            panel_card_add.setVisible(true);
            panel_camping_add.setVisible(false);
            panel_cultural_add.setVisible(false);
            panel_mixed_add.setVisible(false);
            panel_natural_add.setVisible(true);
            panel_summer_add.setVisible(false);
            panel_winter_add.setVisible(false);
        } else if (comboBox_add.getSelectedItem().toString().equalsIgnoreCase("Cultural")) {
            panel_card_add.setVisible(true);
            panel_camping_add.setVisible(false);
            panel_cultural_add.setVisible(true);
            panel_mixed_add.setVisible(false);
            panel_natural_add.setVisible(false);
            panel_summer_add.setVisible(false);
            panel_winter_add.setVisible(false);
        } else if (comboBox_add.getSelectedItem().toString().equalsIgnoreCase("Mixed")) {
            panel_card_add.setVisible(true);
            panel_camping_add.setVisible(false);
            panel_cultural_add.setVisible(false);
            panel_mixed_add.setVisible(true);
            panel_natural_add.setVisible(false);
            panel_summer_add.setVisible(false);
            panel_winter_add.setVisible(false);
        } else { //if tour type did not selected on comboBox
            JOptionPane.showMessageDialog(null, "hata", "try again", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_comboBox_addActionPerformed

    private void tf_region_natural_editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_region_natural_editActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tf_region_natural_editActionPerformed

    private void tabbed_pane_adminKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tabbed_pane_adminKeyPressed


    }//GEN-LAST:event_tabbed_pane_adminKeyPressed

    private void dateChooser_first_addKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dateChooser_first_addKeyPressed

    }//GEN-LAST:event_dateChooser_first_addKeyPressed

    private void dateChooser_first_addİnputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_dateChooser_first_addİnputMethodTextChanged

    }//GEN-LAST:event_dateChooser_first_addİnputMethodTextChanged

    private void bt_show_moneyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_show_moneyActionPerformed
        //show all bought tourNames, numberOfPeople, tourTotalPrice and allTotalMoney
        ta_display_money.setText("");
        double totalMoney = 0;

        for (int i = 0; i < basketlist.size(); i++) {
            if (basketlist.get(i).getHowmany() > 0) {
                ta_display_money.append("\nTour Name: " + basketlist.get(i).getTourName()
                        + "\nNumber of people who buy the tour:" + basketlist.get(i).getHowmany()
                        + "\nTour Total Price:" + basketlist.get(i).getPrice() * basketlist.get(i).getHowmany());
                totalMoney += basketlist.get(i).getPrice() * basketlist.get(i).getHowmany();
            }
        }
        ta_display_money.append("\n\nTOTAL MONEY: " + totalMoney);
    }//GEN-LAST:event_bt_show_moneyActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable CampingTable;
    private javax.swing.JTable CulturalTable;
    private javax.swing.JTable MixedTable;
    private javax.swing.JTable NaturalTable;
    private javax.swing.JTable SummerTable;
    private javax.swing.JTable WinterTable;
    private javax.swing.JButton bt_add;
    private javax.swing.JButton bt_delete;
    private javax.swing.JButton bt_display;
    private javax.swing.JButton bt_edit;
    private javax.swing.JButton bt_search_delete;
    private javax.swing.JButton bt_search_edit;
    private javax.swing.JButton bt_show_money;
    private javax.swing.JComboBox<String> comboBox_add;
    private com.toedter.calendar.JDateChooser dateChooser_finish_edit;
    private com.toedter.calendar.JDateChooser dateChooser_first_add;
    private com.toedter.calendar.JDateChooser dateChooser_last_add;
    private com.toedter.calendar.JDateChooser dateChooser_start_edit;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel panel_add;
    private javax.swing.JPanel panel_camping_add;
    private javax.swing.JPanel panel_camping_edit;
    private javax.swing.JPanel panel_card_add;
    private javax.swing.JPanel panel_card_edit;
    private javax.swing.JPanel panel_cultural_add;
    private javax.swing.JPanel panel_cultural_edit;
    private javax.swing.JPanel panel_delete;
    private javax.swing.JPanel panel_display;
    private javax.swing.JPanel panel_edit;
    private javax.swing.JPanel panel_mixed_add;
    private javax.swing.JPanel panel_mixed_edit;
    private javax.swing.JPanel panel_money;
    private javax.swing.JPanel panel_natural_add;
    private javax.swing.JPanel panel_natural_edit;
    private javax.swing.JPanel panel_summer_add;
    private javax.swing.JPanel panel_summer_edit;
    private javax.swing.JPanel panel_winter_add;
    private javax.swing.JPanel panel_winter_edit;
    private javax.swing.JScrollPane scrollPane_add;
    private javax.swing.JScrollPane scrollPane_add1;
    private javax.swing.JScrollPane scrollPane_add2;
    private javax.swing.JScrollPane scrollPane_add3;
    private javax.swing.JScrollPane scrollPane_add4;
    private javax.swing.JScrollPane scrollPane_add5;
    private javax.swing.JTextArea ta_display_money;
    private javax.swing.JTextArea ta_message_add;
    private javax.swing.JTextArea ta_message_delete;
    private javax.swing.JTextArea ta_message_edit;
    private javax.swing.JTextArea ta_search_result_delete;
    private javax.swing.JTextArea ta_search_result_edit;
    private javax.swing.JTabbedPane tabbed_pane_admin;
    private javax.swing.JTextField tf_beachName_summer_add;
    private javax.swing.JTextField tf_beachName_summer_edit;
    private javax.swing.JTextField tf_bungalowName_natural_add;
    private javax.swing.JTextField tf_bungalowName_natural_edit;
    private javax.swing.JTextField tf_capacity_add;
    private javax.swing.JTextField tf_capacity_edit;
    private javax.swing.JTextField tf_cityName_cultural_add;
    private javax.swing.JTextField tf_cityName_cultural_edit;
    private javax.swing.JTextField tf_cityName_mixed_add;
    private javax.swing.JTextField tf_cityName_mixed_edit;
    private javax.swing.JTextField tf_hotelName_cultural_add;
    private javax.swing.JTextField tf_hotelName_cultural_edit;
    private javax.swing.JTextField tf_hotelName_summer_edit;
    private javax.swing.JTextField tf_hotelName_winter_add;
    private javax.swing.JTextField tf_hotelName_winter_edit;
    private javax.swing.JTextField tf_howManyDay;
    private javax.swing.JTextField tf_howManyDay_edit;
    private javax.swing.JTextField tf_hıtelNAme_summer_add;
    private javax.swing.JTextField tf_imageURL_add;
    private javax.swing.JTextField tf_imageURL_edit;
    private javax.swing.JTextField tf_placeToCampAr_camping_add;
    private javax.swing.JTextField tf_placeToCampAr_camping_edit;
    private javax.swing.JTextField tf_placeToVisit_cultural_add;
    private javax.swing.JTextField tf_placeToVisit_cultural_edit;
    private javax.swing.JTextField tf_placeToVisit_mixed_add;
    private javax.swing.JTextField tf_placeToVisit_mixed_edit;
    private javax.swing.JTextField tf_placeToVisit_natural_add;
    private javax.swing.JTextField tf_placeToVisit_natural_edit;
    private javax.swing.JTextField tf_placeToVisit_summer_add;
    private javax.swing.JTextField tf_placeToVisit_summer_edit;
    private javax.swing.JTextField tf_price_add;
    private javax.swing.JTextField tf_price_edit;
    private javax.swing.JTextField tf_region_natural_add;
    private javax.swing.JTextField tf_region_natural_edit;
    private javax.swing.JTextField tf_region_summer_add;
    private javax.swing.JTextField tf_region_summer_edit;
    private javax.swing.JTextField tf_skiResortName_winter_add;
    private javax.swing.JTextField tf_skiResortName_winter_edit;
    private javax.swing.JTextField tf_tourFinishDate_edit;
    private javax.swing.JTextField tf_tourName_add;
    private javax.swing.JTextField tf_tourName_delete;
    private javax.swing.JTextField tf_tourName_edit;
    private javax.swing.JTextField tf_tourName_search_edit;
    private javax.swing.JTextField tf_tourStartDate_edit;
    private javax.swing.JTextField tf_tourType_edit;
    // End of variables declaration//GEN-END:variables
}
